package sat;

public class GraphColoring {

    public static void main(String[] args) {
        String inPath = args[0];
        String outPath = args[1];
        throw new RuntimeException("To be implemented");
    }

}
